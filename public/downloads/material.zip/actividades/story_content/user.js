function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6Q4tDJBaS7B":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

